package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.AdministratorDAO;
import com.model.Plan;
import com.service.AdministratorService;

/**
 * Servlet implementation class NewPlan
 */
@WebServlet("/NewPlan")
public class NewPlan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewPlan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        HttpSession session = request.getSession();
        int plan_id=Integer.parseInt(request.getParameter("plan_id"));
        String plan_name=request.getParameter("plan_name");
        int plan_amount=Integer.parseInt(request.getParameter("plan_amount"));
        String plan_type=request.getParameter("plan_type");
        //Connection con=null;
        //con=MyDBConnection.getConnection();
        String id=(String)session.getAttribute("cid");
        String status="Inactive";
        Plan p=new Plan(plan_id,plan_name,plan_amount,plan_type);
        AdministratorDAO ad=new AdministratorService();
        int cus=ad.newPlan(p);
        System.out.println(cus);
        if(cus!=0){
        	pw.println("Beneficiary Added");
        	RequestDispatcher rd=request.getRequestDispatcher("CustHome.jsp");
        	rd.include(request, response);
        }
	}

}
