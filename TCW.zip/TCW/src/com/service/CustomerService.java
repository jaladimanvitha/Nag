package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DAO.CustomerDAO;

public class CustomerService implements CustomerDAO{
	Connection con = null;
	PreparedStatement pr = null;
	@Override
	public int rechargeOnline(int cin,int plan_id) {
		// TODO Auto-generated method stub
		int rows=0;
		try {
			pr=con.prepareStatement("update customer set plan_id=? where cin=?");
			pr.setInt(1, plan_id);
			pr.setInt(2, cin);			
			rows=pr.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
		}
		return rows;
		// TODO Auto-generated method stub
		
	}
		

	@Override
	public int payOnline(int cin) {
		int rows = 0;
		// TODO Auto-generated method stub
		try{
			pr=con.prepareStatement("update customerbill set bill_status=? where cin=?");
			pr.setString(1, "PAID");
			pr.setInt(2, cin);
			rows=pr.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
		}
		return rows;
		
		
	}
	
}
