package com.connection;




import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.Statement;




public class DBConnection{
	public static void main(String[] args){
	}
static Connection con=null;

static Connection con1=null;



public static Connection getConnection()

{



try {

Class.forName("oracle.jdbc.driver.OracleDriver");

con=DriverManager.getConnection("jdbc:oracle:thin:@10.53.12.85:1521:xe","Nagendra","1234");

} catch (ClassNotFoundException e) {



e.printStackTrace();

} catch (SQLException e) {

e.printStackTrace();

}

return con;

}
public int updateExec(String sql)
{
    int i = 0 ;
    try{
        con.setAutoCommit(false);
        Statement stmt = con.createStatement() ;
        i = stmt.executeUpdate(sql) ;
        con.commit();
    }
    catch(Exception e)
    {
        System.out.println("Echec de l'exécution de la requête sql :"+e.getMessage());
    }
    return i ;
}

public boolean driver() {
    try {
        Class.forName("com.mysql.jdbc.Driver");
        return true;
    } catch (Exception e) {
        System.out.println("Erreur lors du chargement du pilote :" + e.getMessage());
        return false;
    }
}

public void closeConection()

{

if(con!=null)

try {

con.close();

} catch (SQLException e) {



e.printStackTrace();

}

}

public static Connection getConnection1()

{



try {

Class.forName("oracle.jdbc.driver.OracleDriver");

con1=DriverManager.getConnection("jdbc:oracle:thin:@10.53.12.85:1521:xe","Nagendra","1234");

} catch (ClassNotFoundException e) {



e.printStackTrace();

} catch (SQLException e) {

e.printStackTrace();

}

return con1;

}

public static void closeConection1()

{

if(con1!=null)

try {

con1.close();

} catch (SQLException e) {



e.printStackTrace();

}

}

}