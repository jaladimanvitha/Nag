package com.DAO;

//import com.service.Plan;
import com.model.Plan;
public interface AdministratorDAO {
	public int newPlan(Plan plan);
	public int editPlan(Plan plan);
	//public String writeToUs(int issueId);
}
