package com.DAO;

public interface IssueDAO {
	public int solveIssue(int issue_id,String solution);
}
