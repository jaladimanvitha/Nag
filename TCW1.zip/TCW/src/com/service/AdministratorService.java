package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DAO.AdministratorDAO;
import com.connection.DBConnection;
import com.model.Plan;

public class AdministratorService implements AdministratorDAO{
	Connection con = null;
	PreparedStatement pr = null;
	public int newPlan(Plan plan) {
		try{
			con = DBConnection.getConnection();
			pr=con.prepareStatement("insert into plan values(?,?,?,?)");
			pr.setInt(1, plan.getPlan_id());
			pr.setString(2, plan.getPlan_name());
			pr.setInt(3, plan.getPlan_amount());
			pr.setString(4, plan.getPlan_type());
			
			pr.executeUpdate();
			return 1;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		
		return 0;
		
	}

	@Override
	public int editPlan(Plan plan) {
		int rows=0;
		try {
			pr=con.prepareStatement("Update plan set plan_id=?,plan_name=?,plan_amount=?,plan_type=? where plan_id=?");
			pr.setInt(1, plan.getPlan_id());
			pr.setString(2, plan.getPlan_name());
			pr.setInt(3, plan.getPlan_amount());
			pr.setString(4, plan.getPlan_type());
			
			rows=pr.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
		}
		return rows;
		// TODO Auto-generated method stub
		
	}

}
